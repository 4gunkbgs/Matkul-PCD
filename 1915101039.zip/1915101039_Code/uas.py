import numpy as np
import matplotlib.pyplot as plt
from processing_list import *

# baca image dengan pillow
img = Image.open('Image1.png')
img.show()

# convert to rgb
img_rgb = img.convert('RGB')
# convert to hsv
img_hsv = img.convert('HSV')

# ambil nilai rgb
r, g, b = img_rgb.split()
# ambil nilai hsv
h, s, v = img_hsv.split()

# plotting gambar rgb
fig, ax = plt.subplots(1, 4, figsize=(20, 10))
ax[0].imshow(img_rgb)
ax[0].set_title('RGB')
ax[1].imshow(r)
ax[1].set_title('Red')
ax[2].imshow(g)
ax[2].set_title('Green')
ax[3].imshow(b)
ax[3].set_title('Blue')
plt.show()

# plotting gambar hsv
fig, ax = plt.subplots(1, 4, figsize=(20, 10))
ax[0].imshow(img_hsv)
ax[0].set_title('HSV')
ax[1].imshow(h)
ax[1].set_title('Hue')
ax[2].imshow(s)
ax[2].set_title('Saturation')
ax[3].imshow(v)
ax[3].set_title('Value')
plt.show()

# melihat rentangan nilai pada channel hue
plt.plot(h.histogram())
plt.show()

# rentangan nilai pada channel hue yang akan digunakan
range_hue = [(10, 48), (49, 125), (160, 215), (220, 254)]

# perulangan untuk mengecek apakah nilai pada channel hue berada pada rentangan nilai yang telah ditentukan
hue_img = []
for warna in range_hue:
    hue_pixel = np.zeros((h.size[0], h.size[1]))
    for i in range(h.size[0]):
        for j in range(h.size[1]):
            if h.getpixel((i, j)) > warna[0] and h.getpixel((i, j)) < warna[1]:
                hue_pixel[i, j] = 1
    hue_img.append(hue_pixel)

print(hue_img[0])

# plotting gambar hasil rentangan hue

fig, ax = plt.subplots(1, len(hue_img), figsize=(20, 20))
# ax[0].imshow(img_hsv)
for i in range(len(hue_img)):
    ax[i].imshow(hue_img[i])
    ax[i].set_title('Hue {}'.format(i+1))
plt.show()

# edge detection pada channel value
value_edge = SobelFilter(v, 8)
value_edge

# ubah tepi menjadi warna hitam
for i in range(value_edge.size[0]):
    for j in range(value_edge.size[1]):
        if value_edge.getpixel((i, j)) == 255:
            value_edge.putpixel((i, j), 0)
        else:
            value_edge.putpixel((i, j), 255)

value_edge

# pertajam edge dengan erosion
value_erosion = Erotion(value_edge, 1)
value_erosion


def GabungkanEdge(mask, edge):
    # dapatkan ukuran mask
    h, w = mask.shape

    # buat mask kosong
    new_mask = np.zeros((h, w))

    # masukkan nilai 1 pada mask baru jika nilai pada mask lama adalah 1 dan nilai pada edge image adalah 1
    for i in range(h):
        for j in range(w):
            # cek jika pixel pada mask adalah 1
            if mask[i][j] == 1:
                # cek jika pixel pada edge image adalah 1
                if edge[i][j] == 1:
                    new_mask[i][j] = 1

    # return new mask
    return new_mask


print(hue_img[0].shape)
value_erosion = np.array(value_erosion)
print(value_erosion.shape)

# mengubah value edge x menjadi y dan y menjadi x
value_erosion = np.transpose(value_erosion)

print(hue_img[0].shape)
print(value_erosion.shape)

hue_img[0]

kuning = GabungkanEdge(hue_img[0], value_erosion)
hijau = GabungkanEdge(hue_img[1], value_erosion)
ungu = GabungkanEdge(hue_img[2], value_erosion)
merah = GabungkanEdge(hue_img[3], value_erosion)

fig, ax = plt.subplots(1, 4, figsize=(20, 20))
ax[0].imshow(kuning)
ax[0].set_title('kuning')
ax[1].imshow(hijau)
ax[1].set_title('hijau')
ax[2].imshow(ungu)
ax[2].set_title('ungu')
ax[3].imshow(merah)
ax[3].set_title('merah')
plt.show()
